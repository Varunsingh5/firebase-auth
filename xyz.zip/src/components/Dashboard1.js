import React from 'react';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import Typography from '@material-ui/core/Typography';

export default function Dashboard1(props) {
    const {onlinevalue} = props;

    return (
        <div>
            <div className='cards' style={{ marginTop: '40px', display: 'flex', marginLeft: '50px' }}>
                <Card >
                    <CardContent >
                        <Typography color="textSecondary" gutterBottom style={{ padding: '20px 0px 0px 0px'}}>
                            Online Hours {onlinevalue}
                        </Typography>
                    </CardContent>
                </Card>
                <Card  style={ { marginLeft: '5%' }}  >
                    <CardContent>
                        <Typography color="textSecondary" gutterBottom style={{ padding: '24px 18px 12px 11px' }}>
                            Available
                        </Typography>
                    </CardContent>
                </Card>
                <Card style={{ marginLeft: '5%' }}  >
                    <CardContent>
                        <Typography color="textSecondary" gutterBottom style={{ padding: '24px 35px 12px 28px' }}>
                            Busy
                        </Typography>
                    </CardContent>
                </Card>
                <Card style={{ marginLeft: '5%' }}  >
                    <CardContent>
                        <Typography color="textSecondary" gutterBottom style={{ padding: '24px 18px 12px 11px' }}>
                            Away
                        </Typography>
                    </CardContent>
                </Card>
            </div>
            <div className='cardss' style={{ width: '80%',marginTop:'30px'}}>
                <Card  >
                    <CardContent style={{ display: 'flex' }}>
                        <Typography color="textSecondary" gutterBottom style={{marginLeft: '3%'}}>
                            Time
                        </Typography>
                        <Typography color="textSecondary" gutterBottom style={{ marginLeft: '70%' }}>
                            Status
                        </Typography>
                        <Typography color="textSecondary" gutterBottom style={{ marginLeft: '106px' }}>
                            Duration
                        </Typography>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}