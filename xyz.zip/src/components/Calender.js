import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';

const useStyles = makeStyles((theme) => ({
  container: {
    display: 'flex',
    flexWrap: 'wrap',
  },
  textField: {
    marginLeft: theme.spacing(1),
    marginRight: theme.spacing(1),
    width: 200,
  },
}));

export default function Calender() {
  const classes = useStyles();

  return (
    <form className={classes.container} noValidate style={{marginTop: '56px', marginLeft: '30px'}}>
      <TextField
        id="date"
        type="date"
        defaultValue="12-2-22"
        className={classes.textField}
        InputLabelProps={{
          shrink: true,
        }}
      />
    </form>
  );
}


// import { useState } from "react"
// import DatePicker from "react-multi-date-picker"

// export default function Calender() {
//   const today = new Date()

//   const [values, setValues] = useState([today])

//   return (
//     <div className="date-picker"  style={{marginTop: '25px'}}>
//       <DatePicker
//         multiple
//         value={values}
//         onChange={setValues}
//       />
//     </div>

//   )
// }

